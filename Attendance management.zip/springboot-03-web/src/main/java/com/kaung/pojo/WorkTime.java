package com.kaung.pojo;
import java.sql.Time;
import java.sql.Date;


public class WorkTime {
    private String day;
    private String uid;
    private String sginIn;
    private String inState;
    private String sginOut;
    private String outState;

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getSginIn() {
        return sginIn;
    }

    public void setSginIn(String sginIn) {
        this.sginIn = sginIn;
    }

    public String getInState() {
        return inState;
    }

    public void setInState(String inState) {
        this.inState = inState;
    }

    public String getSginOut() {
        return sginOut;
    }

    public void setSginOut(String sginOut) {
        this.sginOut = sginOut;
    }

    public String getOutState() {
        return outState;
    }

    public void setOutState(String outState) {
        this.outState = outState;
    }

    public WorkTime() {

    }

    public WorkTime(String day, String uid, String sginIn, String inState, String sginOut, String outState) {
        this.day = day;
        this.uid = uid;
        this.sginIn = sginIn;
        this.inState = inState;
        this.sginOut = sginOut;
        this.outState = outState;
    }


}


