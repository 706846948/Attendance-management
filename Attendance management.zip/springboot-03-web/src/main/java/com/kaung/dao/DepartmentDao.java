package com.kaung.dao;


import com.kaung.pojo.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.*;

//部门dao
@Repository
public class DepartmentDao {

    @Autowired
    JdbcTemplate jdbcTemplate;
    //模拟数据库中的数据
    private static Map<Integer, Department> departments = null;
    static {
        departments = new HashMap<Integer,Department>(); //创建一个部门表
        departments.put(101,new Department(101,"教学部"));
        departments.put(102,new Department(102,"市场部"));
        departments.put(103,new Department(103,"教研部"));
        departments.put(104,new Department(104,"运营部"));
        departments.put(105,new Department(105,"后勤部"));
    }

    //获得所有部门信息
    public Collection<Department> getDepartments(){

        String sql = "select * from department";
        List<Map<String,Object>> list_map = jdbcTemplate.queryForList(sql);
        Map<Integer, Department> departments = null;
        departments = new HashMap<Integer,Department>(); //创建一个部门表

        //將map<String，Object>转为 map<Integer,Department>
        List listId = new ArrayList();List listDept = new ArrayList();

        for (Map<String,Object> m:list_map){
            int i = 1;
            for (Map.Entry<String,Object> entry:m.entrySet()){
                System.out.println("key:"+entry.getKey()+"  value:"+ entry.getValue());
                if (i==1)
                    listId.add(entry.getValue());
                if (i==2)
                    listDept.add(entry.getValue());
                i++;
            }
        }

        for (int i=0;i<listId.size();i++){
            int id = (Integer) listId.get(i);
            String departmentName = String.valueOf(listDept.get(i));
            departments.put(i,new Department(id,departmentName));
        }

        return departments.values();
    }

    //通过ID获得部门信息
    public Department getDepartmentById(Integer id){
        return departments.get(id);
    }


}
