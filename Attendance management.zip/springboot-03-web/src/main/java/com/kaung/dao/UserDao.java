package com.kaung.dao;

import com.kaung.pojo.User;
import com.kaung.pojo.WorkTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Repository
public class UserDao {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    private PasswordEncoder passwordEncoder;


    //注册密码加密
    private String encryptPassword(String password) {
        // BCryptPasswordEncoder 加密
        return new BCryptPasswordEncoder().encode(password);
    }


    //注册员工 增加信息
    public void addUser(User user){
        String sql = "insert into user values(?,?,?,?,'user')";
        System.out.println(user.getUid()+" "+user.getUsername()+" " +encryptPassword(user.getPassword())+" " +user.getPhone());
        int count = jdbcTemplate.update(sql,user.getUid(),user.getUsername(),encryptPassword(user.getPassword()),user.getPhone());
        if(count>0) {
            System.out.println("添加成功");
        }else {
            System.out.println("添加失败");
        }
    }


    //查询信息（用户名和密码）
    public String userQuery(String username){
        String sql = "select password from user where username = ?";
        Map<String,Object> map= jdbcTemplate.queryForMap(sql,username);

        List listpw = new ArrayList();
        for (Map.Entry<String,Object> entry:map.entrySet()){
            System.out.println("key:"+entry.getKey()+"  value:"+ entry.getValue());
                listpw.add(entry.getValue());
        }
        String pw = listpw.get(0).toString();
        return pw;
    }

    //获取时间   "yyyy-MM-dd hh:mm:ss"
    public String getTime(String timeStyle){
        Date date = new Date();
        SimpleDateFormat dateFormat= new SimpleDateFormat(timeStyle);
        String curr = dateFormat.format(date);
        return  curr;

    }


    //插入签到时间
    public void sginIn(String username) throws ParseException {
        //根据有户名查询出用户uid
        System.out.println("username="+username);
        String sql = "select uid from user where username = ?";

        Map<String,Object> map= jdbcTemplate.queryForMap(sql,username);

        int uid = toker(map);
        System.out.println("uid="+uid);

        //获取当前日期和签到时间
        String day = getTime("yyyy-MM-dd");
        String sginin = getTime("HH:mm:ss");

        //判断uid的用户是否已经签到，若签到则只改变数据
        String sqlJudge = "select count(uid) from workTime where uid like ? and  day=?";
        Map<String,Object> mapJudge = jdbcTemplate.queryForMap(sqlJudge,uid,day);
        //ans=0表示 用户不存在，否则表示用户已存在
        int ans = toker(mapJudge);



        //设置标准时间
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
        Date date1 = sdf.parse("08:30:00");
        System.out.println("签到时间："+sginin+" "+date1.compareTo(sdf.parse(sginin))+" "+(date1.compareTo(sdf.parse(sginin))>0));

        //签到状态
        String inState;
        if(date1.compareTo(sdf.parse(sginin))>0) inState = "正常";
        else inState = "迟到";

        String sql2;
        int flag;
        if (ans ==0 ) {
            sql2 = "insert into workTime (day,uid,sginin,inState,sginout,outState) values(?,?,?,?,'00:00:00','empty')";
            flag = jdbcTemplate.update(sql2, day, uid, sginin, inState);
        }
        else {
            sql2 = "update workTime set day=?,sginin=?,inState=? where uid=?";
            flag = jdbcTemplate.update(sql2, day, sginin, inState, uid);
        }
        if (flag>0){
            System.out.println("签到成功");
        }else
            System.out.println("签到失败");

    }


    //插入签退时间
    public void sginOut(String username) throws ParseException {
        //根据有户名查询出用户uid
        String sql = "select uid from user where username = ?";

        Map<String,Object> map= jdbcTemplate.queryForMap(sql,username);

        int uid = toker(map);

        //根据uid 、签退时间、签退状态（正常、早退）插入数据
        String sginOut = getTime("HH:mm:ss");
        //设置标准时间
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        Date date1 = sdf.parse("20:30:00");
        String outState;
        if(date1.compareTo(sdf.parse(sginOut))<0) outState = "正常";
        else outState = "早退";
        String sql2 = "update workTime set sginout=?,outState=? where uid=?";

        int flag = jdbcTemplate.update(sql2,sginOut,outState,uid);
        if (flag>0){
            System.out.println("签退成功");
        }else
            System.out.println("签退失败");

    }

    //查询考勤数据表所有信息
    public Collection<WorkTime> getSginAll(String username){
        //根据用户名查询uid
        String sql0 = "select uid from user where username = ?";
        Map<String,Object> maps= jdbcTemplate.queryForMap(sql0,username);
        int id = toker(maps);

        List<Map<String,Object>> list_map;

        String sql;
        if (username.equals("admin")){
            sql = "select * from workTime order by uid";
            list_map = jdbcTemplate.queryForList(sql);
        }
        else{
            sql = "select * from workTime where uid = ? order by uid";
            list_map = jdbcTemplate.queryForList(sql,id);
        }
        //获取所有用户信息


        Map<Integer, WorkTime> workTime = new HashMap<Integer,WorkTime>();
        int i=0;
        for (Map<String,Object> map:list_map) {
            List list = new ArrayList();
            for (Map.Entry<String, Object> entry : map.entrySet()) {
//                System.out.println("key:" + entry.getKey() + "  value:" + entry.getValue()+ entry.getValue().getClass());
                list.add(entry.getValue());
            }
            workTime.put(i,new WorkTime(list.get(0).toString(),list.get(1).toString(),list.get(2).toString(),
                    list.get(3).toString(),list.get(4).toString(),list.get(5).toString()));
            i++;
        }
        return workTime.values();
    }

    //查询某一个人的考勤信息
    public User querySgin(String username){
        String sql = "select * from workTime where username = ?";

        return new User();
    }



    //提取map<String,Object>中的数据值
    public int toker(Map<String,Object> map){
        List list = new ArrayList();
            for (Map.Entry<String,Object> entry : map.entrySet()){
                System.out.println("key:"+entry.getKey()+"  value:"+ entry.getValue());
                list.add(entry.getValue());
            }
        if (list.size()==0)
            return 0;
        int ans = Integer.parseInt(list.get(0).toString());
        System.out.println("ans:"+ans);
        return ans;
    }










}
