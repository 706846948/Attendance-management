package com.kaung.config;


import com.kaung.dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        //不跳转到springSecurity的默认登录界面，而是自己指定界面
        http.formLogin().loginPage("/user/login").usernameParameter("username").passwordParameter("password");;

        //生成cookie，默认保存两周
        http.rememberMe();
        //防止网站工具：get ，post
        http.csrf().disable(); //关闭csrf

        //生成cookie，默认保存两周
        http.rememberMe();



        //定义请求规则
        http.authorizeHttpRequests()
                .antMatchers("/").permitAll()
//                .antMatchers("/user/**").permitAll()
                .antMatchers("/emp/list.html").hasRole("admin")
                .antMatchers("/individual/sgin.html").hasRole("user");

    }

//    @Override
//    protected void configure(AuthenticationManagerBuilder auth)throws Exception{
//        String sql = "select username,password,roles from user";
//        List<Map<String,Object>> list = jdbcTemplate.queryForList(sql);
//        List<List> massage = new ArrayList();
//        for(Map<String,Object> map :list) {
//            List mass = new ArrayList();
//            for (Map.Entry<String, Object> entry : map.entrySet()) {
//                System.out.println("key:" + entry.getKey() + " values: " + entry.getValue());
//                mass.add(entry.getValue());
//            }
//            massage.add(mass);
//        }
//        System.out.println(list);
//
//
//        auth.inMemoryAuthentication().passwordEncoder(new BCryptPasswordEncoder())
//            .withUser("testuser").password(new BCryptPasswordEncoder().encode("123456")).roles("user")
//            .and()
//            .withUser("testadmin").password(new BCryptPasswordEncoder().encode("123456")).roles("admin");
//
//
////
////
////        auth.inMemoryAuthentication().passwordEncoder(new BCryptPasswordEncoder())
////                .withUser("admin").password(new BCryptPasswordEncoder().encode("admin")).roles("admin");
//
//
//   }

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }
}
