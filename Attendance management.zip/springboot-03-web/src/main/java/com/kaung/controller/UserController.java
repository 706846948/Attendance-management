package com.kaung.controller;


import com.kaung.dao.UserDao;
import com.kaung.pojo.Employee;
import com.kaung.pojo.User;
import com.kaung.pojo.WorkTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.util.Collection;

@Controller
    public class UserController {

    @Autowired
    UserDao userDao;

    //进入注册界面
    @GetMapping(value = "/register")
    public String register(){

        System.out.println("进入注册页面");
        return "register";
    }

    //提交注册信息
    @PostMapping(value = "/register")
    public String regSuccess(User user){
        userDao.addUser(user);
        System.out.println(user.getUid()+user.getUsername()+""+user.getPassword()+""+user.getPhone());
        return "index";
    }

    //进行签到
    @RequestMapping(value = "/individual/sgin")
    public String sgin(){
        return "individual/sgin.html";
    }

    //用户签到
    @RequestMapping(value = "/sginIn")
    public String sginIn(HttpSession session) throws ParseException {
        String username = session.getAttribute("loginUser").toString();
        userDao.sginIn(username);

        return "individual/sgin.html";
    }

    //用户签退
    @RequestMapping(value = "/sginOut")
    public String sginOut(HttpSession session) throws ParseException {
        String username = session.getAttribute("loginUser").toString();
        userDao.sginOut(username);

        return "individual/sgin.html";
    }

    //查看所有用户信息
    @RequestMapping("/sgins")
    public String list(Model model,HttpSession session)throws  ParseException {
        System.out.println("进入考勤记录");
        Collection<WorkTime> workTimes  = userDao.getSginAll(session.getAttribute("loginUser").toString());
        model.addAttribute("worktimes", workTimes);
        return "sginList";

    }




}
