package com.kaung.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.kaung.dao.DepartmentDao;
import com.kaung.dao.EmployeeDao;
import com.kaung.pojo.Department;
import com.kaung.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class DepartmentController {
    @Autowired
    EmployeeDao employeeDao;

    @Autowired
    DepartmentDao departmentDao;

    @Autowired
    JdbcTemplate jdbcTemplate;

//    @RequestMapping("/deptList")
//    public String deptList(Model model){
//        Collection<Department> departments = departmentDao.getDepartments();
//        Collection<Employee> employees = employeeDao.getAll();
//        model.addAttribute("depts",departments);
//        return "emp/list_dept";
//
//    }

    @RequestMapping("/deptList")
    public String departmentList(Model model){

        Collection<Department> depts = departmentDao.getDepartments();
        model.addAttribute("depts",depts);
        return "emp/list_dept";
    }

}
