package com.kaung.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RouterController {

    @RequestMapping(value = {"/","/index"})
    public String index(){
        return "index";
    }

    @RequestMapping(value = "/toLogin")
    public String toLogin(){
        System.out.println("登录成功");
        return "views/login.html";
    }

    @RequestMapping(value = "/level1/{id}")
    public String level1(@PathVariable("id") Integer id){
        System.out.println("进入0页面");
        return "views/level0/"+id;
    }
    @RequestMapping(value = "/level2/{id}")
    public String level2(@PathVariable("id") Integer id){
        return "views/level2/"+id;
    }
    @RequestMapping(value = "/level3/{id}")
    public String level3(@PathVariable("id") Integer id){
        return "views/level3/"+id;
    }
}
