package com.kaung.controller;


import com.kaung.dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.thymeleaf.util.StringUtils;

import javax.servlet.http.HttpSession;

@Controller
public class LoginController {


    @Autowired
    UserDao userDao;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @RequestMapping(value = "/user/login")
    public String login(
            @RequestParam("username") String username,
            @RequestParam("password") String password,
            Model model, HttpSession session){
        //具体业务：
        //通过用户名查询密码
        String pw = userDao.userQuery(username);
//        System.out.println(pw+" "+password);
        //passwordEncoder.matches(密码进行比对
//        if( passwordEncoder.matches(password, pw)){
        if(password.equals(pw)){
            session .setAttribute("loginUser",username);
            session .setAttribute("loginpass",password);
            System.out.println("LoginMain");
            return "redirect:/main.html";
        }else{
            model.addAttribute("msg","用户名或密码错误！");
            return "index";
        }
    }


    @RequestMapping(value = "/user/logout")
    public String logout(HttpSession session){
        session.invalidate();
        return "redirect:/index.html";
    }
}
